from pygame import *
import random
init()
# level 1,scroll 0-800, 920-1720, 1840-2640

#declaring the variables
game_state='menu'
clock = time.Clock()
screen = display.set_mode((800, 432))
display.set_caption("The Forest")
running = True
c_x = 0
c_y = 300
scroll = 0
ground_image = image.load("images/background/ground.png").convert_alpha() #load the images that will be used
menu_bg=image.load("images/menu/bg.png")
title=image.load("images/menu/title.png")
play=image.load("images/menu/play.png") 
help=image.load("images/menu/help.png") 
ground_width = ground_image.get_width()
ground_height = ground_image.get_height()
facing = 'right'   #varibales used for animation
char_state = 'idle'
player_death_animation=[]
player_idle_animation = []  # idle animation
player_run_animation = []
player_run_que = 0
player_idle_que = 0
player_idle_tick = 0
player_run_tick = 0
enemy_idle_tick = 0
enemy_run_tick = 0
player_health = 100  #player data
word_font = font.SysFont("Arial", 25)
RED = (255, 0, 0)   #colors
GREEN = (0, 255, 0)
GREY = (159, 159, 157)
BLACK = (0, 0, 0)
level = 'Safe'   #gameplay tracker
right_bound = 0
on_ground = True
jump_once = False
death_font=font.SysFont("Arial", 35)
you_lost_text=death_font.render("You have died...",1,BLACK)
bg_music = mixer.music.load("sfx/music.wav")
mixer.music.set_volume(0.1)   #bg musics
mixer.music.play(-1)
shot_cool = 0
level1_enx = [625, 675, 730]    #enemy data
level1_en_state = ['idle', 'idle', 'idle']
level1_en_facing = ['left', 'left', 'left']
level1_en_deathcomp = [False, False, False]
enemy1_health = 100  #enemy health
enemy2_health = 50
enemy3_health = 50
#each enemy's object with its corresponded real time data, different enemy have different damage, health
enemy1_stat = [enemy1_health, level1_enx[0], 300, level1_en_facing[0], 'enemy', level1_en_state[0], 0, 0, 1, 1, 100, 0, 0, 4000, 2000, 2,0,300]
enemy2_stat = [enemy2_health, level1_enx[1], 300, level1_en_facing[1], 'enemy', level1_en_state[1], 1, 1, 2, 2, 50, 0, 0, 4200, 2500, 5,5000,340]
enemy3_stat = [enemy3_health, level1_enx[2], 300, level1_en_facing[2], 'enemy', level1_en_state[2], 2, 2, 3, 3, 50, 0, 0, 4500, 3000, 5,7000,390]
enemy_list1 = [enemy1_stat, enemy2_stat, enemy3_stat]
spawn_en = False      #gameplay assisting variables
player_death_tick=0
player_death_que=0
is_defeated=False
right_bound=0
enemy_spawned=False
instruction=image.load("images/menu/instruction.png")
x=image.load("images/menu/x.png")
bullet_img = image.load("images/bullet/bullet.png")
player_bulletx = []   #positional variables, checks the position of an object in real time
player_bullety = []
player_bullet_facing = []
enemy_bulletx = []
enemy_bullety = 332
enemy_bullet_damage = []
enemy_bullet_facing = []
enemy_run_animation = []
enemy_idle_animation = []
enemy_death_animation = []
enemy_run_que = 0
enemy_idle_que = 0
bg_images = []  # load the background images
bg_width = 768
cool_down_start = time.get_ticks()
gravity = 1
finishing_level_count=1
is_defeat=False
player_death_completed=False

for i in range(8):  #load all the required animation images using for loops
    char=image.load(f"images/char/death/{i}.png")
    char=transform.scale(char,(28*2,36*2))
    player_death_animation.append(char)

for i in range(8):
    char = image.load(f"images/enemy/death/{i}.png")
    char = transform.scale(char, (28 * 2, 36 * 2))
    enemy_death_animation.append(char)
for i in range(5):
    char = image.load(f"images/enemy/idle/{i}.png")
    char = transform.scale(char, (28 * 2, 36 * 2))
    enemy_idle_animation.append(char)

for i in range(6):
    char = image.load(f"images/enemy/run/{i}.png")
    char = transform.scale(char, (28 * 2, 36 * 2))
    enemy_run_animation.append(char)

for i in range(5):
    char = image.load(f"images/char/idle/{i}.png")
    char = transform.scale(char, (28 * 2, 36 * 2))  # makes the character bigger
    player_idle_animation.append(char)

for i in range(6):
    char = image.load(f"images/char/run/{i}.png")
    char = char = transform.scale(char, (28 * 2, 36 * 2))
    player_run_animation.append(char)

for i in range(1, 6):  # load all the character images
    bg_image = image.load(f"images/background/bg-{i}.png").convert_alpha()
    bg_images.append(bg_image)

def draw_bg():  # draw all the background images
    for x in range(10):
        speed = 1
        for i in bg_images:
            screen.blit(i, ((x * bg_width) - scroll * speed,0))  # the background is pushed to the interface
            speed += 0.2  #creates a parrallax effect

def draw_ground():  #draw the grass terrain
    for x in range(22):
        screen.blit(ground_image, ((x * ground_width) - scroll * 2, 432 - ground_height))

def jump(vel_dy, gravity):  #player jumping system
    global cool_down_start
    global c_y
    global jump_once
    global on_ground
    c_y += vel_dy + gravity
    if (c_y == 300):   #every counted seconds, a gravity is applied to push player to the ground
        cool_down_start = time.get_ticks()
        jump_once = False
        on_ground = True
    return vel_dy + gravity

def check_level(scroll):  #determine boundaries of each level
    global level
    global right_bound
    if (scroll == 0):
        level = 'safe'
        right_bound = 2
        moveback = -1
        return moveback
    elif (scroll >= right_bound and scroll <= 300*finishing_level_count):
        level = 'level 1'
        right_bound = 300*finishing_level_count
        moveback = right_bound-80
        
        return moveback
    return 300*finishing_level_count-80

def next_level(is_defeated):   #check if the enemies in current level is defeated
    global level
    if(level!='Safe' and is_defeated==True):
        return True
    else:
        return False
def check_alive(health):  #check if an instance is alive
    if (health > 0):
        return True
    else:
        return False

def idle_update(idle_tick, qeue): #update the animation for the object idleing
    if (idle_tick == 7):
        if (qeue < 4):
            return 0, qeue + 1
        else:
            return 0, 0

    return idle_tick + 1, qeue

def run_update(run_tick, qeue): #update the animation for the objects that are running
    if (run_tick == 7):
        if (qeue < 4):
            return 0, qeue + 1
        else:
            return 0, 0
    return run_tick + 1, qeue

def death_update(tick, qeue): #update the death animation for objects
    if (tick == 7):
        if (qeue < 7):
            return 0, qeue + 1
        else:
            return 0, 0
    return tick + 1, qeue


def player_death(player_death_tick,player_death_que):  #animating the player's death
    global player_death_completed
    player_death_tick,player_death_que=death_update(player_death_tick,player_death_que)
    if(facing=='right'):  #check the facing of the player to determine if needed to flip the image
        screen.blit(player_death_animation[player_death_que],(c_x,c_y))
        if(player_death_que==7):
            player_death_completed=True
        return player_death_tick,player_death_que
    elif(facing=='left'): #check if it is facing left
        screen.blit(transform.flip(player_death_animation[player_death_que], True, False), (c_x,c_y))
        if (player_death_que == 7):
            player_death_completed = True
        return player_death_tick,player_death_que

def character(c_x, c_y, facing, type, state, enemy_list):  #draw the character on the screen of the specified object (player/enemy)
    global player_idle_tick
    global player_run_tick
    global player_idle_que
    global player_run_que
    global level1_en_deathcomp

    if (type == 'enemy'): #if it is an enemy
        counter = 0
        for enemy in (enemy_list):
            if (state[counter] == 'idle'): #check the state of the enemy, display it on screen
                enemy_idle_tick, enemy_idle_que = idle_update(enemy[6], enemy[8])
                if (level1_en_facing[counter] == 'right'):
                    screen.blit(enemy_idle_animation[enemy_idle_que], (enemy[1], 300))
                elif (level1_en_facing[counter == 'left']):
                    screen.blit(transform.flip(enemy_idle_animation[enemy_idle_que], True, False), (enemy[1], 300))
                enemy[6] = enemy_idle_tick
                enemy[8] = enemy_idle_que
                enemy_list[counter] = enemy
            elif (state[counter] == 'run'): #display running animation if state is running
                enemy_run_tick, enemy_run_que = run_update(enemy[7], enemy[9])
                if (level1_en_facing[counter] == 'right'): #check which way the enemy is running
                    screen.blit(enemy_run_animation[enemy_run_que], (enemy[1], 300))
                elif (level1_en_facing[counter == 'left']):
                    screen.blit(transform.flip(enemy_run_animation[enemy_run_que], True, False), (enemy[1], 300))
                enemy[7] = enemy_run_tick
                enemy[9] = enemy_run_que
                enemy_list[counter] = enemy

            elif (state[counter] == 'dead'): #if the enemy is dead, display the animation
                enemy_death_tick, enemy_death_que = death_update(enemy[11], enemy[12]) #update each tick
                if (level1_en_facing[counter] == 'right'): #check the facing
                    screen.blit(enemy_death_animation[enemy_death_que], (enemy[1], 300))
                elif (level1_en_facing[counter == 'left']):
                    screen.blit(transform.flip(enemy_death_animation[enemy_death_que], True, False), (enemy[1], 300))
                enemy[11] = enemy_death_tick
                enemy[12] = enemy_death_que
                if (enemy[12] == 7): #if the enemy has completed death animation return true and remove it from the enemy list
                    level1_en_deathcomp[counter] = True
                enemy_list[counter] = enemy

            counter += 1
        return enemy_list
    elif (type == 'player'): #if drawing is for player
        if (state == 'idle'): #check if it is idle state
            player_idle_tick, player_idle_que = idle_update(player_idle_tick, player_idle_que)
            if (facing == 'right'): #check the facing and display the animation
                screen.blit(player_idle_animation[player_idle_que], (c_x, c_y))
            elif (facing == 'left'):
                screen.blit(transform.flip(player_idle_animation[player_idle_que], True, False), (c_x, c_y))
        elif (state == 'run'): #if running, display run animation
            player_run_tick, player_run_que = run_update(player_run_tick, player_run_que)
            if (facing == 'right'):
                screen.blit(player_run_animation[player_run_que], (c_x, c_y))
            elif (facing == 'left'):
                screen.blit(transform.flip(player_run_animation[player_run_que], True, False), (c_x, c_y))
        elif (state == 'jump'): #if jumping, display jump animation
            char = image.load('images/char/jump/0.png')
            char = transform.scale(char, (28 * 2, 36 * 2))
            if (facing == 'right'):
                screen.blit(char, (c_x, c_y))
            elif (facing == 'left'):
                screen.blit(transform.flip(char, True, False), (c_x, c_y))
#used to add the existance of a bullet
def bullet(facing, c_x, c_y, type, enemy, damage):
    shot_sfx = mixer.Sound("sfx/shot.wav") #play the sound of a gunshot
    shot_sfx.play()
    # player width 28
    if (type == 'player'):  #if the bullet is shot by a player
        if (facing == 'right'): #update bullet position regarding to the facing
            player_bulletx.append(c_x + 48)
        elif (facing == 'left'):
            player_bulletx.append(c_x - 10)
        player_bullet_facing.append(facing)
        player_bullety.append(c_y + 32)
    elif (type == 'enemy'): #if shot by enemy
        if (facing == 'right'): #update the x_cord of the bullet
            enemy_bulletx.append(enemy[1] + 48)
            enemy_bullet_damage.append(damage)
        elif (facing == 'left'):
            enemy_bulletx.append(enemy[1] - 10)
            enemy_bullet_damage.append(damage)
        enemy_bullet_facing.append(facing)
    return time.get_ticks()

#draw the bullet on the screen
def draw_bullet(bulletx, bullety, facing, object, enemy_list, damage):
    screen.blit(bullet_img, (bulletx, bullety))
    if_hit, enemy, index = hit(bulletx, bullety, object, enemy_list)
    if (if_hit): #check if an object is being hit by bullet
        if(object=='player' and enemy_spawned==True): #if enemy is shot
            new_enemy_list = reduce_health(enemy, index, enemy_list, damage, object) #deduct health for enemy
            return bulletx, bullety, True, new_enemy_list
        else:
            new_enemy_list = reduce_health(enemy, index, enemy_list, damage, object)
            return bulletx, bullety, True, new_enemy_list
    if (facing == 'right'): #if not hit, continue updating x coords for the bullet
        return bulletx + 6, bullety, False, -1
    elif (facing == 'left'):
        return bulletx - 6, bullety, False, -1

#reduce the health of an instance when hit by bullet
def reduce_health(enemy, index, enemy_list, damage, object):
    global player_health
    if (object == 'player'):
        enemy[0] -= damage
        enemy_list[index] = enemy
        return enemy_list
    elif (object == 'enemy'):
        player_health -= damage

#check if an instance is hit by a bullet
def hit(bulletx, bullety, object, enemy_list):  # object is whoever shot the bullet
    if (object == 'player'):
        counter = 0
        for i in enemy_list:
            if (bulletx >= i[1] and bulletx <= i[1] + 28 and bullety >= 300): #check collisions
                return True, enemy_list[counter], counter
            counter += 1
        return False, -1, -1
    elif (object == 'enemy'):
        if (bulletx >= c_x and bulletx <= c_x + 35 and bullety >= c_y and bullety <= c_y + 36 * 2):
            return True, enemy_list, 0
        return False, -1, -1

#blit the health bar on the screen
def draw_health_bar(health, obj_x, obj_y, max_health, type):
    if (type == 'player'): #blit player's health bar
        draw.rect(screen, GREY, (obj_x, obj_y - 10, 50, 10))
        percentage = health / max_health
        draw.rect(screen, GREEN, (obj_x, obj_y - 10, 50 * percentage, 10))
        draw.rect(screen, BLACK, (obj_x, obj_y - 10, 50, 10), 1)
    elif (type == 'enemy'): #blit enemy health bar
        draw.rect(screen, GREY, (obj_x, obj_y - 10, 50, 10))
        percentage = health / max_health
        draw.rect(screen, RED, (obj_x, obj_y - 10, 50 * percentage, 10))
        draw.rect(screen, BLACK, (obj_x, obj_y - 10, 50, 10), 1)

def you_lost(lab_count): #count down for closing the window
    global running
    screen.blit(you_lost_text,(270,200))
    if(time.get_ticks()-lab_count>=5000):
        running=False

def enemy_AI(enemy_list, facing): #the enemy engine, the core of the game
    global level1_en_facing
    global level1_en_state
    counter = 0
    for enemy in enemy_list: 
        if (time.get_ticks() - enemy[13] >= enemy[14]): #for every designated second, the enemy can shoot
            enemy[13] = time.get_ticks()
            enemy_list[counter] = enemy
            if (level == 'level 1'):
                if(enemy[1]>=c_x):  #determining the facing of the bullet will be
                    facing[counter]='left'
                    level1_en_facing[counter]='left'
                elif(enemy[1]<=c_x):
                    facing[counter]='right'
                    level1_en_facing[counter]='right'
                bullet(facing[counter], enemy[1], 300, 'enemy', enemy, enemy[15]) #create the bullet instance
        if(time.get_ticks()-enemy[16]>=3000): #every 3 seconds the enemy is able to move to a specific distance away from the player
            if(enemy[1]>c_x):
                if(enemy[1]<0): #checking if player is at left right
                    enemy[1]=0
                elif(enemy[1]>750):
                    enemy[1]=750
                if(enemy[1]-c_x>enemy[17] and enemy[1]>=0 and enemy[1]<=750):
                    level1_en_facing[counter]='left'
                    level1_en_state[counter]='run'
                    enemy[1]-=4 #move the enemy accordingly
                    if(enemy[1]-c_x<=enemy[17]):
                        level1_en_state[counter]='idle'
                        if(enemy[1]>c_x):
                            level1_en_facing[counter]='left'
                        elif(enemy[1]<c_x):
                            level1_en_facing[counter]='right'
                        enemy[16]=time.get_ticks()
                    #needs to move left
                elif(enemy[1]-c_x<enemy[17] and enemy[1]>=0 and enemy[1]<=750):
                    level1_en_facing[counter] = 'right'
                    level1_en_state[counter] = 'run'
                    enemy[1] += 4
                    if (enemy[1] - c_x >= enemy[17]):
                        level1_en_state[counter]='idle'
                        if (enemy[1] > c_x):
                            level1_en_facing[counter] = 'left'
                        elif (enemy[1] < c_x):
                            level1_en_facing[counter] = 'right'
                        enemy[16] = time.get_ticks()
                    #needs to move right
        enemy_list[counter]=enemy
        counter += 1 #counter used to determine which enemy it is
    return enemy_list

while running:
    if(game_state=='menu'): #check if the state is menu
        for e in event.get():
            if e.type == QUIT:
                running = False
        screen.blit(menu_bg,(0,0)) #draw the menu screen
        screen.blit(title,(175,30))
        mousex,mousey=mouse.get_pos()
        if(mousex>=230 and mousex<=372 and mousey>=300 and mousey<=399):  #check for collisions between boxes and mouse coord
            screen.blit(transform.scale(play,(142*1.1,99*1.1)),(230,300))
            mousex=mouse.get_pressed()[0]
            if(mousex): #if clicked play button, state becomes play
                game_state='play'
        else:
            screen.blit(play,(230,300))
        if(mousex>=400 and mousex<=400+156 and mousey>=300 and mousey<=399):
            screen.blit(transform.scale(help,(156*1.1,99*1.1)),(400,300))
            mousex=mouse.get_pressed()[0]
            if(mousex): #if hit instruction button state become instruction
                game_state='instruction'
        else:
            screen.blit(help,(400,300))
    elif(game_state=='instruction'):
        mousex,mousey=mouse.get_pos()
        for e in event.get():
            if e.type == QUIT:
                running = False
        screen.blit(transform.scale(instruction,(800,432)),(0,0))
        if(mousex>=740 and mousex<=780 and mousey>=20 and mousey<=60): 
            screen.blit(transform.scale(x,(42,42)),(740,20))
            mousex=mouse.get_pressed()[0]
            if(mousex): #if hit the exit button, quit to menu page
                game_state='menu'
        else:
            screen.blit(x,(740,20))
    elif(game_state=='play'): #if playing
        player_stat = [c_x, c_y, facing, 'player', char_state] #define the player stats
        characters = [player_stat]
        for e in event.get(): #if the user wants to quit the program
            if e.type == QUIT:
                running = False
        display_level = word_font.render(f"Current Level: level {finishing_level_count}", 1, (0, 0, 0)) #display current level
        p_alive = check_alive(player_health) #check if player is alive
        clock.tick(60)
        draw_bg() #draw backgrounds
        draw_ground()
        screen.blit(display_level, (300, 40)) 
        if (check_alive(player_health)):
            for i in (characters):  # draw the player and its health bar
                draw_health_bar(player_health, c_x, c_y, 100, 'player')
                character(i[0], i[1], i[2], i[3], i[4], 0)
                player_alive=True
        elif(check_alive(player_health)==False and player_death_completed==False): #if player is dead, change the state to dead
            player_stat='dead'
            player_death_tick,player_death_que=player_death(player_death_tick,player_death_que)
            player_alive=False
            if(player_death_que==7): #if the animation is completed start 5 second count down before exiting the game
                lab_count_down=time.get_ticks()
        if(player_death_completed==True):
            you_lost(lab_count_down) #display that you have lost
        if (level == 'level 1' and spawn_en == True and enemy_spawned==True and player_alive==True):
            enemy_list1 = enemy_AI(enemy_list1, level1_en_facing) #call the enemy_AI function to animate enemies
        if (level == 'level 1' and spawn_en == True and time.get_ticks() - spawn_delay >= 200):
            count = 0
            enemy_spawned=True
            if(len(enemy_list1)==0 and spawn_en==True and enemy_spawned==True): #check if there are dead enemies
                is_defeated=True
            for i in (enemy_list1):
                if (i[0] <= 0):
                    level1_en_state[count] = 'dead'
                    if (level1_en_deathcomp[count] == True):  #if enemy dies, delete its info on the list
                        enemy_list1.pop(count)
                        level1_enx.pop(count)
                        level1_en_state.pop(count)
                        level1_en_facing.pop(count)
                        level1_en_deathcomp.pop(count)
                draw_health_bar(i[0], i[1], 300, i[10], 'enemy') #update the health bar for enemy
                count += 1
            enemy_list1 = character(0, 0, 0, 'enemy', level1_en_state, enemy_list1)
        moveback = check_level(scroll)
        if_next_level=next_level(is_defeated)
        
        is_defeated=False
        if(if_next_level):
            #check if next level is coming
            enemy_spawned=False
            if(player_health<=80):
                player_health+=20
            else:
                player_health+=100-player_health
            #buff health for enemy
            enemy1_stat[0]=enemy1_stat[10]+20
            enemy1_stat[10]=enemy1_stat[0]
            enemy2_stat[0]=enemy2_stat[10]+20
            enemy2_stat[10]=enemy2_stat[0]
            enemy3_stat[0]=enemy3_stat[10]+20
            enemy3_stat[10]=enemy3_stat[0]
            #buff speed for enemy
            enemy1_stat[14]-=5
            enemy2_stat[14]-=5
            enemy3_stat[14]-=5
            #buff damage for enemy
            enemy1_stat[15]+=1
            enemy2_stat[15]+=1
            enemy3_stat[15]+=1
            #add facing for enemy
            enemy1_stat[11]=0
            enemy1_stat[12]=0
            enemy2_stat[11]=0
            enemy2_stat[12]=0
            enemy3_stat[11]=0
            enemy3_stat[12]=0
            #add the states
            level1_enx = [625, 675, 730]
            level1_en_state = ['idle', 'idle', 'idle']
            level1_en_facing = ['left', 'left', 'left']
            level1_en_deathcomp = [False, False, False]
            spawn_en=False

            enemy1_stat[16]=random.randrange(1000,2000)
            enemy2_stat[16]=random.randrange(3500,6000)
            enemy3_stat[16]=random.randrange(4000,7000)

            enemy_list1.append(enemy1_stat)
            enemy_list1.append(enemy2_stat) 
            enemy_list1.append(enemy3_stat)
            finishing_level_count+=1
            if_level=False


        # bullet draw checks if you need to draw a bullet
        for index in range(len(player_bulletx)):
            if (level == 'level 1'):
                player_bulletx[index], player_bullety[index], hitted, new_enemy_list1 = draw_bullet(player_bulletx[index],player_bullety[index],player_bullet_facing[index], 'player',enemy_list1, 15)
                if (player_bulletx[index] >= 800 or player_bulletx[index] <= 0 or hitted == True):
                    player_bulletx.pop(index)
                    player_bullety.pop(index)
                    player_bullet_facing.pop(index)
                    if (hitted == True):
                        enemy_list1 = new_enemy_list1
                    break

        # checking enemy bullet, see if any hits, needs to be drawn, etc
        for index in range(len(enemy_bulletx)):
            enemy_bulletx[index], enemy_bullety, hitted, new_player_stat = draw_bullet(enemy_bulletx[index], enemy_bullety,enemy_bullet_facing[index], 'enemy',player_stat,enemy_bullet_damage[index])  #
            if (enemy_bulletx[index] >= 800 or enemy_bulletx[index] <= 0 or hitted == True):
                enemy_bulletx.pop(index)
                break

        # if the player is on ground
        if (on_ground == True):
            char_state = 'idle'
        key_press = key.get_pressed()
        # if jumped
        if (jump_once == True):
            vel_y = jump(vel_y, gravity)
        if (on_ground == True):
            vel_y = -15
        # if players move left or right
        if (key_press[K_d] and player_alive==True):#player moves to the righ
            if (on_ground == True):
                char_state = 'run'
            facing = 'right'
            if (scroll < right_bound):  #making the parallax effect
                if (level != 'safe' and scroll >= moveback and scroll < right_bound):
                    c_x -= 12
                    scroll += 2
                    if (scroll >= right_bound): #when reach a specific point, start spawing enemies
                        spawn_delay = time.get_ticks()
                        spawn_en=True
                if (c_x < 504):
                    c_x += 2
                if (c_x == 504):
                    scroll += 2
                    if (scroll == right_bound):
                        right_bound -= 1
            if (scroll == right_bound and c_x < 748):
                c_x += 2
        if (key_press[K_a] and player_alive==True):#player moves to the left
            if (on_ground == True):
                char_state = 'run'
            facing = 'left'
            if (c_x >= 0):
                c_x -= 2

        if (key_press[K_SPACE] and on_ground == True and time.get_ticks() - cool_down_start >= 150 and player_alive==True): #set the player to jump
            char_state = 'jump'
            on_ground = False
            jump_once = True

        click = mouse.get_pressed()
        if (click[0] and level == 'level 1' and spawn_en == True and player_alive==True and enemy_spawned==True):  # shooting
            if (time.get_ticks() - shot_cool >= 700):
                shot_cool = bullet(facing, c_x, c_y, 'player', 0, 0)
    
    display.update()