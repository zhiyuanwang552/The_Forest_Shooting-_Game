1. when finding the player stucked, unable to move to the next right to go to the next level, go left for a bit and then go right

2. every level you beat, the enemy gets stronger, you also gain 20 unit of health for every level you beat

3. This is an advanture game, if you die, you need to restart the program as like you have re-born into the world